import { Router } from "express";
import CommentController from "../controllers/comentarios.controller.js";
import { verifyToken } from "../middleware/authMiddleware.js";

const router = Router();
const name = "/comment";

// Middleware para verificar token
router.use(verifyToken);

// Rutas para registrar y listar comentarios
router.route(name)
  .post(CommentController.createComment)
  .get(CommentController.getAllComments);

// Rutas para operaciones por ID
router.route(`${name}/:id`)
  .get(CommentController.getCommentById)
  .put(CommentController.updateComment)
  .delete(CommentController.deleteComment);

export default router;
