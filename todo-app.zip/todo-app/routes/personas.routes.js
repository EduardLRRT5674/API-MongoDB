import { Router } from "express";
import PersonaController from "../controllers/personas.controller.js";
import { verifyToken } from "../middleware/authMiddleware.js";

const router = Router();
const name = "/persona";

// Middleware para verificar token
router.use(verifyToken);

// Rutas para registrar y listar personas
router.route(name)
  .post(PersonaController.addPersona)
  .get(PersonaController.show);

// Rutas para operaciones por ID
router.route(`${name}/:id`)
  .get(PersonaController.findById)
  .put(PersonaController.update)
  .delete(PersonaController.delete);

export default router;
