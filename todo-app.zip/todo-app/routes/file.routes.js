import { Router } from "express";
import FileController from '../controllers/file.controller.js';
import { verifyToken } from '../middleware/authMiddleware.js';

const router = Router();
const name = "/file";

// Verify token middleware
router.use(verifyToken);

// Route for task registration and list
router.route(name)
  .post(FileController.addTask)
  .get(FileController.show);

// Route for task by ID
router.route(`${name}/:id`)
  .get(FileController.findById)
  .put(FileController.update)
  .delete(FileController.delete);

export default router;