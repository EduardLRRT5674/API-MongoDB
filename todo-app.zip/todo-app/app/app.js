import express from 'express';
import { connectDB } from '../config/db/connection.js';


import authRouter from '../routes/auth.routes.js';
import userRouter from '../routes/user.routes.js';
import commentRoutes from '../routes/comment.routes.js';
import task from "../routes/task.routes.js";
import persona from "../routes/personas.routes.js";
import file from "../routes/file.routes.js";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

connectDB();

app.use('/api', authRouter);
app.use('/api', userRouter);
app.use('/api', commentRoutes);
app.use('/api', task);
app.use('/api', persona);
app.use('/api', file);

app.use((rep, res, nex) => {
    res.status(404).json({
        message: 'Endpoint losses'
    })
});

export default app;