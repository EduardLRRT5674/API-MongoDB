import { mongoose } from '../config/db/connection.js';

const personaSchema = new mongoose.Schema({
  correo: { type: String, required: true, unique: true },
  encargados: [{ type: String }], // puedes cambiar a ObjectId si luego quieres relaciones
  creadoPor: { type: String, required: true } // también puede ser un ObjectId si hace referencia a users
}, {
  timestamps: true // agrega createdAt y updatedAt
});

export default mongoose.model('personas', personaSchema);
