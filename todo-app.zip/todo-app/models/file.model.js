import { mongoose } from "../config/db/connection.js";

const fileSchema = new mongoose.Schema(
  {
    size: { type: String, required: true },
    format: { type: String, required: true, enum: ["PDF", "PNG", "DOCX"] },
    url: {type: String,required: true},
  },
  {
    collection: "file",
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" },
  }
);

export default mongoose.model("file", fileSchema);
