import { mongoose } from "../config/db/connection.js";
const { Schema } = mongoose;

const assigneedSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "users", required: true },
    username: { type: String, required: true },
    email: { type: String, required: true },
  },
  { _id: false }
);

const taskSchema = new Schema(
  {
    title: { type: String, required: true },
    description: { type: String },
    type: { type: String, required: true, enum: ["Bug", "Feature", "Task"] },
    priority: { type: String, required: true, enum: ["Alta", "Media", "Baja"] },
    color: { type: String },
    status: {
      type: String,
      required: true,
      enum: ["Pendiente", "En progreso", "Completada"],
    },
    start_date: { type: Date },
    end_date: { type: Date },
    assigness: [assigneedSchema],
  },
  {
    collection: "tasks",
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" },
  }
);

export default mongoose.model("tasks", taskSchema);
