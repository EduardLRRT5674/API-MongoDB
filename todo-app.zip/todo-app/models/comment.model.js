import { mongoose } from '../config/db/connection.js';

const comentarioSchema = new mongoose.Schema({
    comment: { type: String, required: true },
    idperson: { type: mongoose.Schema.Types.ObjectId, ref: 'person', required: true },
    starDate: { type: Date, default: Date.now },
    updateDate: { type: Date, default: Date.now },
});


comentarioSchema.pre('save', function (next) {
    this.updateDate = new Date();
    next();
});

comentarioSchema.pre('findOneAndUpdate', function (next) {
    this.set({ updateDate: new Date() });
    next();
});

export default mongoose.model('comment', comentarioSchema);
