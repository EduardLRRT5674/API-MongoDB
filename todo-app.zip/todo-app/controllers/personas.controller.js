import PersonaModel from "../models/personas.model.js";
import dotenv from "dotenv";

dotenv.config();

class PersonaController {
  // Crear nueva persona
  async addPersona(req, res) {
    try {
      const { correo, encargados, creadoPor } = req.body;

      if (!correo || !creadoPor) {
        return res.status(400).json({ error: "Correo y creadoPor son obligatorios" });
      }

      const existingPersona = await PersonaModel.findOne({ correo });
      if (existingPersona) {
        return res.status(400).json({ error: "La persona ya existe" });
      }

      const newPersona = new PersonaModel({ correo, encargados, creadoPor });
      await newPersona.save();

      return res.status(201).json({ message: "Persona registrada exitosamente" });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  // Mostrar todas las personas
  async show(req, res) {
    try {
      const personas = await PersonaModel.find();
      if (!personas) throw new Error("No se encontraron personas");

      return res.status(200).json({ data: personas });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  // Actualizar persona
  async update(req, res) {
    try {
      const { correo, encargados, creadoPor } = req.body;

      if (!correo || !creadoPor) {
        return res.status(400).json({ error: "Correo y creadoPor son obligatorios" });
      }

      const existingPersona = await PersonaModel.findOne({ _id: req.params.id });
      if (!existingPersona) {
        return res.status(404).json({ error: "Persona no encontrada" });
      }

      const updatedPersona = await PersonaModel.findByIdAndUpdate(
        req.params.id,
        { correo, encargados, creadoPor },
        { new: true }
      );

      if (!updatedPersona) {
        return res.status(404).json({ error: "No se pudo actualizar la persona" });
      }

      return res.status(200).json(updatedPersona);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  // Buscar persona por ID
  async findById(req, res) {
    try {
      const id = req.params.id;
      if (!id) {
        return res.status(400).json({ error: "Se requiere el ID" });
      }

      const persona = await PersonaModel.findById(id);
      if (!persona) {
        return res.status(404).json({ error: "Persona no encontrada" });
      }

      return res.status(200).json({ data: persona });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  // Eliminar persona
  async delete(req, res) {
    try {
      const deletedPersona = await PersonaModel.findByIdAndDelete(req.params.id);
      if (!deletedPersona) {
        return res.status(404).json({ error: "Persona no encontrada o ya eliminada" });
      }

      return res.status(200).json({ message: "Persona eliminada correctamente" });
    } catch (error) {
      res.status(500).json({ error: "Error al eliminar la persona" });
    }
  }
}

export default new PersonaController();
