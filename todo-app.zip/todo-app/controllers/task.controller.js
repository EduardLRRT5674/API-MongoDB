import TaskModel from "../models/task.model.js";
import UserModel from "../models/user.model.js"; 

class TaskController {
  async addTask(req, res) {
    try {
      const {
        title,
        description,
        type,
        priority,
        color,
        status,
        start_date,
        end_date,
        assigness,
      } = req.body;

      if (
        !title || !type || !priority || !status ||
        !Array.isArray(assigness) || assigness.length === 0
      ) {
        return res
          .status(400)
          .json({ error: "Todos los campos obligatorios deben ser completados" });
      }

      const populatedAssigness = await Promise.all(
        assigness.map(async (userId) => {
          const user = await UserModel.findById(userId).select("username email");
          if (!user) {
            throw new Error(`Usuario con ID ${userId} no encontrado`);
          }

          return {
            userId: user._id,
            username: user.username,
            email: user.email,
          };
        })
      );

      const newTask = new TaskModel({
        title,
        description,
        type,
        priority,
        color,
        status,
        start_date,
        end_date,
        assigness: populatedAssigness,
      });

      await newTask.save();
      return res.status(201).json({ message: "Tarea creada exitosamente", data: newTask });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  }

  async show(req, res) {
    try {
      const tasks = await TaskModel.find();
      return res.status(200).json({ data: tasks });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  }

  // Buscar tarea por ID
  async findById(req, res) {
    try {
      const { id } = req.params;
      const task = await TaskModel.findById(id);
      if (!task) return res.status(404).json({ error: "Tarea no encontrada" });

      return res.status(200).json({ data: task });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  }

  // Actualizar tarea
  async update(req, res) {
    try {
      const { id } = req.params;
      const {
        title,
        description,
        type,
        priority,
        color,
        status,
        start_date,
        end_date,
        assigness,
      } = req.body;

      const updateFields = {
        title,
        description,
        type,
        priority,
        color,
        status,
        start_date,
        end_date,
      };

      if (Array.isArray(assigness) && assigness.length > 0) {
        const populatedAssigness = await Promise.all(
          assigness.map(async (userId) => {
            const user = await UserModel.findById(userId).select("username email");
            if (!user) {
              throw new Error(`Usuario con ID ${userId} no encontrado`);
            }

            return {
              userId: user._id,
              username: user.username,
              email: user.email,
            };
          })
        );

        updateFields.assigness = populatedAssigness;
      }

      const updatedTask = await TaskModel.findByIdAndUpdate(id, updateFields, {
        new: true,
      });

      if (!updatedTask) {
        return res.status(404).json({ error: "Tarea no encontrada o no actualizada" });
      }

      return res.status(200).json({ data: updatedTask });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  }


  async delete(req, res) {
    try {
      const { id } = req.params;
      const deletedTask = await TaskModel.findByIdAndDelete(id);

      if (!deletedTask) {
        return res.status(404).json({ error: "Tarea no encontrada" });
      }

      return res.status(200).json({ message: "Tarea eliminada correctamente" });
    } catch (err) {
      return res.status(500).json({ error: "Error al eliminar la tarea" });
    }
  }
}

export default new TaskController();
