import UserModel from '../models/user.model.js';
import dotenv from 'dotenv';

dotenv.config();

class UserController {
    async addUser(req, res) {
        const passwordRex = /^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,16}$/;
        try {
            const { username, email, password } = req.body;
            if (!username || !email || !password) {
                return res.status(400).json({ error: 'All data is mandatory for entry' });
            }
            if (!passwordRex.test(password)) {
                return res.status(400).json({ error: 'The password must be between 8 and 16 characters long, with at least one digit, one lowercase letter, one uppercase letter, and one non-alphanumeric character.' });
            }

            const existingUser = await UserModel.findOne({ email });
            if (existingUser) {
                return res.status(400).json({ error: 'The user already exists' });
            }

            const newUser = new UserModel({ username, email, password });
            await newUser.save();

            return res.status(201).json({ message: 'User successfully registered' });

        } catch (err) {
            return res.status(400).json({ error: err.message });
        }
    }

    async show(req, res) {
        try {
            const users = await UserModel.find();
            return res.status(200).json({ data: users });
        } catch (err) {
            res.status(400).json({ error: err.message });
        }
    }

    async findById(req, res) {
        try {
            const id = req.params.id;
            if (!id) {
                return res.status(400).json({ error: 'User ID is required' });
            }
            const user = await UserModel.findById(id);
            if (!user) throw new Error('User not found');
            return res.status(200).json({ data: user });
        } catch (err) {
            res.status(400).json({ error: err.message });
        }
    }

    async update(req, res) {
        const passwordRex = /^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,16}$/;
        try {
            const { username, email, password } = req.body;
            if (!username || !email || !password) {
                return res.status(400).json({ error: 'All data is mandatory for entry' });
            }
            if (!passwordRex.test(password)) {
                return res.status(400).json({ error: 'The password must be between 8 and 16 characters long, with at least one digit, one lowercase letter, one uppercase letter, and one non-alphanumeric character.' });
            }

            const updatedUser = await UserModel.findByIdAndUpdate(
                req.params.id,
                { username, email, password },
                { new: true }
            );

            if (!updatedUser) {
                return res.status(404).json({ error: 'User not updated' });
            }

            res.status(200).json({ message: 'User updated successfully', data: updatedUser });
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    }

    async delete(req, res) {
        try {
            const deletedUser = await UserModel.findByIdAndDelete(req.params.id);
            if (!deletedUser) {
                return res.status(404).json({ error: 'User not found for deletion' });
            }
            res.status(200).json({ message: 'Deleted successfully' });
        } catch (err) {
            res.status(500).json({ error: 'Error deleting user' });
        }
    }
}

export default new UserController();
