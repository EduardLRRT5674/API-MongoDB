import FileModel from '../models/file.model.js'; // Asegúrate de que la ruta sea correcta

class FileController {

  async addTask(req, res) {
    try {
      const {
        size,
        format,
        url
      } = req.body;

      if (
        !size || !format || !url
      ) {
        return res.status(400).json({ error: 'All required fields must be filled' });
      }

      const newFile = new FileModel({
        size,
        format,
        url
      });

      await newFile.save();
      return res.status(201).json({ message: 'File successfully created' });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  }


  async show(req, res) {
    try {
      const files = await FileModel.find();
      return res.status(200).json({ data: files });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  }


  async findById(req, res) {
    try {
      const { id } = req.params;
      const task = await FileModel.findById(id);
      if (!task) return res.status(404).json({ error: 'File not found' });

      return res.status(200).json({ data: file });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  }

  // Actualizar tarea
  async update(req, res) {
    try {
      const { id } = req.params;
      const {
        size,
        format,
        url
      } = req.body;

      const updatedFile = await FileModel.findByIdAndUpdate(
        id,
        {
          size,
          format,
          ulr
        },
        { new: true }
      );

      if (!updatedFile) {
        return res.status(404).json({ error: 'File not found or not updated' });
      }

      return res.status(200).json(updatedFile);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  }


  async delete(req, res) {
    try {
      const { id } = req.params;
      const deletedFile = await FileModel.findByIdAndDelete(id);

      if (!deletedFile) {
        return res.status(404).json({ error: 'File not found' });
      }

      return res.status(200).json({ message: 'File successfully deleted' });
    } catch (err) {
      return res.status(500).json({ error: 'Error deleting File' });
    }
  }
}

export default new FileController();
